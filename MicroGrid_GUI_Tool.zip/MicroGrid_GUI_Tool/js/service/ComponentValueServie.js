'use strict';
var docType = angular.module('componentTypeService', []);
docType.value('ComponentTypes',{
	componentList : [
		
		{
			name : 'Sensor',
			type : 'Sensor',
			id:'1',
			properties : [],
			namespace :'MicroGrid.OnePhase.Components.Sensor.Sensor',
			subComponent:['SubComponentA','SubComponentB','SubComponentC'],
			icon : 'img\\sensor.png'
		},
		
		{name : 'Resistive',type : 'Resistive',id:'2',properties : [],namespace : 'MicroGrid.OnePhase.Components.Load.Resistive',subComponent:['SubComponentA','SubComponentB','SubComponentC'],icon : 'img\\resistive.png'},
		{name : 'FeederTie',type : 'FeederTie',id:'3',properties : [],namespace : 'MicroGrid.OnePhase.Components.Switch.FeederTie',subComponent:['SubComponentA','SubComponentB','SubComponentC'],icon : 'img\\newFeeder.png'},
		{name : 'PowerSource',type : 'PowerSource',id:'4',properties : [{name : 'P_Capacity',value:''},{name : 'P_in',value:''}],namespace : 'MicroGrid.OnePhase.Sources.PowerSource',subComponent:['SubComponentA','SubComponentB','SubComponentC'],icon : 'img\\powersource.png'},
		{name : 'NewFeeder',type : 'NewFeeder',id:'5',properties : [],namespace : 'MicroGrid.OnePhase.Components.Transmission.NewFeeder',subComponent:['SubComponentA','SubComponentB','SubComponentC'],icon : 'img\\newFeeder.png'},
		{name : 'BooleanPulse',type : 'BooleanPulse',id:'6',properties : [{name : 'width',value:''}],namespace : 'MicroGrid.OnePhase.Sources.PowerSource',subComponent:['SubComponentA','SubComponentB','SubComponentC']},
		{name : 'constant',type : 'Constant',id:'7',properties : [{name : 'K',value:''}], namespace : 'Modelica.Blocks.Sources.Constant',subComponent:['SubComponentA','SubComponentB','SubComponentC']}
		],
linkList :['v_in_left','v_out_left','v_in_right','v_out_right','N','P','I','y','Right','Left','terminal','V_in','v_in','V_out','v_out','V_in_right','V_in_left','control_R','control_L','feder'],
controllerList : [
	{
		Name : " HOMER CYCLE CHARGING", //provide space before Name
		description : "Controller description",
		capabilities :[
			{
				Component : "Generator",
				properties : 
					[
					{name : 'MinQty',value :'0'},
					{name :'MinQty',value : '0'},
					{name : 'Bus',value : 'AC or DC'}
					]
			},
			{
				Component : "Turbine",
				properties : 
					[
					{name : 'MinQty',value :'0'},
					{name :'MinQty',value : '0'},
					{name : 'Bus',value : 'AC or DC'}
					]
			},
			{
				Component : "WindMill",
				properties : 
					[
					{name : 'MinQty',value :'0'},
					{name :'MinQty',value : '0'},
					{name : 'Bus',value : 'AC or DC'}
					]
			}
		]
			
	},

	{
		Name : "  Controller2",
		description : "Controller description",
		capabilities :[
			{
				Component : "Generator",
				properties : 
					[
					{name : 'MinQty',value :'0'},
					{name :'MinQty',value : '0'},
					{name : 'Bus',value : 'AC or DC'}
					]
			},
			{
				Component : "Turbine",
				properties : 
					[
					{name : 'MinQty',value :'0'},
					{name :'MinQty',value : '0'},
					{name : 'Bus',value : 'AC or DC'}
					]
			},
			{
				Component : "W",
				properties : 
					[
					{name : 'MinQty',value :'0'},
					{name :'MinQty',value : '0'},
					{name : 'Bus',value : 'AC or DC'}
					]
			}
		]
			
	},

	{
		Name : " Controller3",
		description : "Controller description",
		capabilities :[]
	}
	]

});


